<template>
  <div style="padding:30px;">
    <iframe src="http://192.168.1.125:3000/d/nKtIC5YiA/ce-shi-huan-jing-zookeeper?orgId=1&theme=light&var-devname=pet-zk&var-interval=1m" width="100%" height="1000" frameborder="0"></iframe>
      </div>

  </div>
</template>
