<template>
  <div style="padding:30px;">

<iframe src="http://192.168.1.125:3000/d-solo/icjpCppik/cluster?orgId=1&refresh=1m&theme=light&panelId=6" width="33.333%" height="150" frameborder="0"></iframe>
<iframe src="http://192.168.1.125:3000/d-solo/icjpCppik/cluster?orgId=1&refresh=1m&theme=light&panelId=4" width="33.333%" height="150" frameborder="0"></iframe>
<iframe src="http://192.168.1.125:3000/d-solo/icjpCppik/cluster?orgId=1&refresh=1m&theme=light&panelId=7" width="33.333%" height="150" frameborder="0"></iframe>

  <iframe src="http://192.168.1.125:3000/d-solo/icjpCppik/cluster?orgId=1&refresh=1m&theme=light&panelId=2051" width="100%" height="220" frameborder="0"></iframe>

<iframe src="http://192.168.1.125:3000/d-solo/icjpCppik/cluster?orgId=1&refresh=1m&theme=light&panelId=2052" width="100%" height="220" frameborder="0"></iframe>
<iframe src="http://192.168.1.125:3000/d-solo/icjpCppik/cluster?orgId=1&refresh=1m&theme=light&panelId=2053" width="100%" height="220" frameborder="0"></iframe>
  </div>
</template>
