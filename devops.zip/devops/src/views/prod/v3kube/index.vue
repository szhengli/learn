<template>
  <div style="padding:30px;">
<iframe src="http://grafana-rngdqgfijjkwddkqfr.grafana.aliyuncs.com:31002/d-solo/1399783668292805-31498-21/kubernetesgai-lan?orgId=1&theme=light&refresh=30s&panelId=4" width="33.33%" height="180" frameborder="0"></iframe>
<iframe src="http://grafana-rngdqgfijjkwddkqfr.grafana.aliyuncs.com:31002/d-solo/1399783668292805-31498-21/kubernetesgai-lan?orgId=1&theme=light&refresh=30s&panelId=6" width="33.33%" height="180" frameborder="0"></iframe>
<iframe src="http://grafana-rngdqgfijjkwddkqfr.grafana.aliyuncs.com:31002/d-solo/1399783668292805-31498-21/kubernetesgai-lan?orgId=1&theme=light&refresh=30s&panelId=7" width="33.33%" height="180" frameborder="0"></iframe>
<iframe src="http://grafana-rngdqgfijjkwddkqfr.grafana.aliyuncs.com:31002/d-solo/1399783668292805-31498-413/node-summary?&orgId=1&theme=light&panelId=185" width="100%" height="420" frameborder="0"></iframe>
<iframe src="http://grafana-rngdqgfijjkwddkqfr.grafana.aliyuncs.com:31002/d-solo/1399783668292805-31498-21/kubernetesgai-lan?orgId=1&theme=light&refresh=30s&panelId=25" width="100%" height="200" frameborder="0"></iframe>

  </div>
</template>
