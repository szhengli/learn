
<script>
  const InternalPrometheus = "http://192.168.1.125:3000/d-solo"
  
  export default
  {
    InternalPrometheus,
  }
  
</script>

